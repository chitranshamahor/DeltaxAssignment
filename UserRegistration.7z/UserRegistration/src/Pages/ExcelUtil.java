package Pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class ExcelUtil {

	public void readExcel(String filePath,String fileName,String sheetName) throws IOException{

	    

	    File file =    new File(filePath+"\\"+fileName);

	    FileInputStream inputStream = new FileInputStream(file);

	    Workbook TestDatWB = null;
	    
	    String fileExtensionName = fileName.substring(fileName.indexOf("."));
	    

	    Sheet TestDataSheet = TestDatWB.getSheet(sheetName);



	    int rowCount = TestDataSheet.getLastRowNum()-TestDataSheet.getFirstRowNum();


	    
	    
	    for (int i = 0; i < rowCount+1; i++) {

	        Row row = TestDataSheet.getRow(i);

	   

	        for (int j = 0; j < row.getLastCellNum(); j++) {

	        

	            System.out.print(row.getCell(j).getStringCellValue()+"|| ");
	            
	            

	        }

	        System.out.println();

	    }

	     
	    
	}
}
