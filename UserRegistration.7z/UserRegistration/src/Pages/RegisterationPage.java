package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class RegisterationPage {
	
	private static WebElement element = null;
	 
	// Eelement First name
    public static WebElement txtbx_FirstName(WebDriver driver){
 
         element = driver.findElement(By.name("first_name"));
         
         return element;
 
         }
    
 // Eelement Last name
    public static WebElement txtbx_LastName(WebDriver driver){
    	 
        element = driver.findElement(By.name("last_name"));
        
        return element;

        }
    
 // Eelement user name
    public static WebElement txtbx_UserName(WebDriver driver){
   	 
        element = driver.findElement(By.name("user_name"));
        
        return element;

        }

 // Eelement Password
    public static WebElement txtbx_UserPassword(WebDriver driver){
      	 
        element = driver.findElement(By.name("user_password"));
        
        return element;

        }
    
    
 // Eelement Confirm password
    public static WebElement txtbx_ConfirmPassword(WebDriver driver){
     	 
        element = driver.findElement(By.name("confirm_password"));
        
        return element;

        }
    
 // Eelement Email
    public static WebElement txtbx_Email(WebDriver driver){
    	 
        element = driver.findElement(By.name("email"));
        
        return element;

        }
    
 // Eelement Contact no
    
    public static WebElement txtbx_ContactNo(WebDriver driver){
   	 
        element = driver.findElement(By.name("contact_no"));
        
        return element;

        }
    
    
 // Eelement Department
    public static WebElement txtbx_Department(WebDriver driver){
      	 
    	 element = driver.findElement(By.name("department"));
    	//Select dropdown= new Select(mySelectElement);
    //	element=dropdown.selectByVisibleText("Sales");
    	
        return element;

        }
    
 // Eelement Submit Button
    public static WebElement txtbx_Submit(WebDriver driver){
      	 
    	 element = driver.findElement(By.cssSelector("glyphicon.glyphicon-send"));
    	
        return element;

        }
    
    // Validation text
    
   /* public static String txtbx_Validationtext(WebDriver driver, String S1){

   			 String S3="This value is not valid";
   		String S =driver.findElement(By.xpath(S1)).getText();
   		if (S==S3)
   			
   		{
       return S;
       
   		}

    }*/
    
}
