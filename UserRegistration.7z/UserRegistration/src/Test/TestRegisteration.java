package Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Pages.ExcelUtil;
import Pages.RegisterationPage;

public class TestRegisteration {

	
	public WebDriver driver;
	
	ExcelUtil objExcelFile = new ExcelUtil();
	WebDriverWait wait;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
		
		@BeforeSuite
		 
		  public void beforeMethod() {
			
			System.setProperty("webdriver.chrome.driver",".\\chromedriver.exe");
	          
	          ChromeOptions options = new ChromeOptions();
	          options.addArguments("test-type");
	          options.addArguments("--start-maximized");
	         // options.addArguments("--disable-web-security");
	          options.addArguments("--user-data-dir");
	          options.addArguments("--allow-running-insecure-content");
	          options.setCapability("chrome.binary",".\\chromedriver.exe");
	          driver = new ChromeDriver(options);
		
		 
		      //Put a Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception
		 
		      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		      driver.manage().window().maximize();
		      //Launch the Online Store Website	 
		      driver.get("http://adjiva.com/qa-test/");
		     
		}
		
		
		// Method 1: Success Registeration
		  
		  @Test (priority=3)	
		  
		  public void userSuccessRegisteration() {
			 
			  // Entering First name
			  RegisterationPage.txtbx_FirstName(driver).clear();
			  RegisterationPage.txtbx_FirstName(driver).sendKeys("Chitra");
			   
			  
			// Entering Last name
			  RegisterationPage.txtbx_LastName(driver).clear();
			  RegisterationPage.txtbx_LastName(driver).sendKeys("Mahor");
			  
			// Entering User name
			  RegisterationPage.txtbx_UserName(driver).clear();
			  RegisterationPage.txtbx_UserName(driver).sendKeys("TestingAuto"); 
			     
			 
			// Entering Password 
			  RegisterationPage.txtbx_UserPassword(driver).clear();
			  RegisterationPage.txtbx_UserPassword(driver).sendKeys("TestingAuto");
			 
				// Entering confirm Password
			  RegisterationPage.txtbx_ConfirmPassword(driver).clear();
			  RegisterationPage.txtbx_ConfirmPassword(driver).sendKeys("TestingAuto");
			  
			// Entering Email
			  RegisterationPage.txtbx_Email(driver).clear();
			  RegisterationPage.txtbx_Email(driver).sendKeys("TestingAuto@gmail.com");
			  
			// Submit Form
	
			  RegisterationPage.txtbx_Submit(driver).click();
			  
			  // Verify Thank you page
			  
			  Assert.assertTrue(driver.getCurrentUrl().contains("thanks"));
			  
			     System.out.println("User Registered successfully");
			
			     
			     WebDriverWait wait=new WebDriverWait(driver,60);
			     
		  }
		  
		
		
// Method 2: failed Registeration
		  
		  @Test (priority=1)	
		  
		  public void userfailedRegisteration() {
		
			  try 
			  {
			// Submit Form
				 
			  RegisterationPage.txtbx_Submit(driver).click();
			  
		
			  // validate First name message
			  
			  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[1]/div/small[2]")).getText(), "Please enter your First Name");
			  
			  
 // validate Last name message
			  
			  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[2]/div/small[2]")).getText(), "Please enter your Last Name");
			  
// validate user name message
			  
			  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[4]/div/small[2]")).getText(), "Please enter your Username");
			  
			  
// validate password message
			  
			  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[5]/div/small[2]")).getText(), "Please enter your Password");
			  
			  
// validate confirm password message
			  
			  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[6]/div/small[2]")).getText(), "Please confirm your Password");
			  
			  
// validate Email message
			  
			  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[7]/div/small[1]")).getText(), "Please enter your Email Address");
			  
			  }
			  
			  catch
			  
			  (NoSuchElementException exception) {
				  System.out.println("Elements not found");
			    }
			  
			     System.out.println("User Registeration Failed");
			
			 
			     
		  }
		  

// Method 3: Form Validations
		  
		  @SuppressWarnings("deprecation")
		@Test (priority=2)	
		  
		  public void FormValidations()  throws IOException{
			  
			  
			  File src=new File(".\\src\\TestAssignment_Testcases.xls");
			  
				FileInputStream finput = new FileInputStream(src);
				 workbook = new HSSFWorkbook(finput);
				 sheet= workbook.getSheetAt(1);
				 
			
				for(int i=1; i<sheet.getLastRowNum(); i++)
				 {
					 // Import data for FirstNAme.
					 cell = sheet.getRow(i).getCell(1);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					
					//  "A" or "1" or "11" or "@" or "!!" value checks last value will be "Chitra"
					 
					 RegisterationPage.txtbx_FirstName(driver).clear();
					  RegisterationPage.txtbx_FirstName(driver).sendKeys(cell.getStringCellValue());
					  
					  //Assert.assertEquals(driver.findElement(By.className("help-block")).getText(), "This value is not valid");
					  
					  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[1]/div/small[1]")).getText(), "This value is not valid");
					 
					 // Import data for LastNAme.
					 cell = sheet.getRow(i).getCell(2);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					 RegisterationPage.txtbx_LastName(driver).clear();
					  RegisterationPage.txtbx_LastName(driver).sendKeys(cell.getStringCellValue());
					  
					//  Assert.assertEquals(driver.findElement(By.className("help-block")).getText(), "This value is not valid");
					  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[2]/div/small[1]")).getText(), "This value is not valid");
					  
					// Validating User name
					  RegisterationPage.txtbx_UserName(driver).clear();
					  RegisterationPage.txtbx_UserName(driver).sendKeys(cell.getStringCellValue()); 
					     
					  
					  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[4]/div/small[2]")).getText(), "This value is not valid");
					 
					   		
					  
					// Validating Password 
					  RegisterationPage.txtbx_UserPassword(driver).clear();
					  RegisterationPage.txtbx_UserPassword(driver).sendKeys(cell.getStringCellValue()); 
					  
					  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[5]/div/small[2]")).getText(), "This value is not valid");
					 
						// Validating confirm Password
					  RegisterationPage.txtbx_ConfirmPassword(driver).clear();
					  RegisterationPage.txtbx_ConfirmPassword(driver).sendKeys(cell.getStringCellValue()); 
					  
					  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[6]/div/small[2]")).getText(), "This value is not valid");
					  
					  
					  
						// Validating Email
						  RegisterationPage.txtbx_Email(driver).clear();
						  RegisterationPage.txtbx_Email(driver).sendKeys(cell.getStringCellValue()); 
						  
						  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[7]/div/small[2]")).getText(), "This value is not valid");
						  
						  
						// Validating Contact
						  RegisterationPage.txtbx_ContactNo(driver).clear();
						  RegisterationPage.txtbx_ContactNo(driver).sendKeys(cell.getStringCellValue()); 
						  
						  Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"contact_form\"]/fieldset/div[8]/div/small[2]")).getText(), "This value is not valid");
						  
						
						  
						// Submit Form
							
						  RegisterationPage.txtbx_Submit(driver).click();
						  
						  Assert.assertFalse(driver.getCurrentUrl().contains("thanks"));
						  
						 
					  
			        }
				 
			
			 
		
			  
	
			     
		  }
		  
		  
		  @AfterSuite
		  
		  public void afterMethod() {
		 
			  // Close the driver
			  
		  		driver.close();
		  		
		      driver.quit();
		     
		     
		  }

		  
		  
}
